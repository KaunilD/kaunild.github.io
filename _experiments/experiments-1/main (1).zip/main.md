
## CNN + SVM

* Here we try to examine the performance of a CNN classifier against using CNN as a feature extractor and using SVM as the final classifier. 


```python
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
```


```python
class Data:
    def __init__(self, data):
        self._x = list(data[:, 1])
        self._y = data[:, 0]
        x_len = len(self._x[0])
        for xdx, x in enumerate(self._x):
            pixels = []
            lable = None
            for idx, i in enumerate(x.split(' ')):
                pixels.append(int(i))
            pixels = np.array(pixels).reshape((1, 48, 48))
            self._x[xdx] = pixels
            self._y[xdx] = int(self._y[xdx])
        self._x = np.array(self._x).reshape((len(self._x), 1, 48, 48))
        self._y = np.array(self._y)
```


```python
class FileReader:
    def __init__(self, csv_file_name):
        self._csv_file_name = csv_file_name
    def read(self):
        data = pd.read_csv(self._csv_file_name)
        self._data = data.values
```


```python
file_reader = FileReader('fer2013/fer2013.csv')
file_reader.read()
```


```python
data = Data(file_reader._data)
```

#### Preprocess the data 


```python
data._x = np.asarray(data._x, dtype=np.float64)
data._x -= np.mean(data._x, axis = 0)
data._x /= np.std(data._x, axis = 0)
```


```python
for ix in range(10):
    plt.figure(ix)
    plt.imshow(data._x[ix].reshape((48, 48)), interpolation='none', cmap='gray')
plt.show()
```


![png](output_8_0.png)



![png](output_8_1.png)



![png](output_8_2.png)



![png](output_8_3.png)



![png](output_8_4.png)



![png](output_8_5.png)



![png](output_8_6.png)



![png](output_8_7.png)



![png](output_8_8.png)



![png](output_8_9.png)



```python
split_ratio = 0.8

train_indices = np.random.choice(len(data._x), int(len(data._x)*split_ratio))
test_indices = [i for i in range(len(data._x)) if i not in train_indices]

x_train, y_train = data._x[train_indices], data._y[train_indices]
x_valid, y_valid = data._x[test_indices], data._y[test_indices]
```

#### Implementation of CNN Architecture


```python
class CNN(nn.Module):
    def __init__(self, num_classes=7):
        super(CNN, self).__init__()

        self.layer1 = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=5),
            nn.PReLU(),
            nn.ZeroPad2d(2),
            nn.MaxPool2d(kernel_size=5, stride=2)
        )

        self.layer2 = nn.Sequential(
            nn.ZeroPad2d(padding=1),
            nn.Conv2d(64, 64, kernel_size=3),
            nn.PReLU(),
            nn.ZeroPad2d(padding=1)
        )

        self.layer3 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3),
            nn.PReLU(),
            nn.AvgPool2d(kernel_size=3, stride=2)
        )

        self.layer4 = nn.Sequential(
            nn.ZeroPad2d(1),
            nn.Conv2d(128, 128, kernel_size=3),
            nn.PReLU()
        )

        self.layer5 = nn.Sequential(
            nn.ZeroPad2d(1),
            nn.Conv2d(128, 128, kernel_size=3),
            nn.PReLU(),
            nn.ZeroPad2d(1),
            nn.AvgPool2d(kernel_size=3, stride=2)
        )

        self.fc1 = nn.Linear(3200, 1024)
        self.prelu = nn.PReLU()
        self.dropout = nn.Dropout(p=0.2)
        self.fc2 = nn.Linear(1024, 1024)
        self.fc3 = nn.Linear(1024, 7)
        self.log_softmax = nn.LogSoftmax(dim=1)
    def forward(self, x):

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.layer5(x)

        x = x.view(x.size(0), -1)

        x = self.fc1(x)
        x = self.prelu(x)
        x = self.dropout(x)

        x = self.fc2(x)
        x = self.prelu(x)
        x = self.dropout(x)

        y = self.fc3(x)
        y = self.log_softmax(y)
        return y
```

#### Dataset for pytorch DataLoader


```python
class FER2013Dataset(Dataset):
    """FER2013 Dataset."""

    def __init__(self, X, Y, transform=None):
        """
        Args:
            csv_file (string): Path to the csv file with annotations.
            root_dir (string): Directory with all the images.
            transform (callable, optional): Optional transform to be applied
                on a sample.
        """
        self.transform = transform
        self._X = X
        self._Y = Y
        
    def __len__(self):
        return len(self._X)

    def __getitem__(self, idx):
        return {'inputs': self._X[idx], 'labels': self._Y[idx]}
```

#### Network hyperparameters 


```python
NUM_EPOCHS = 100
BATCH_SIZE = 128
LR = 0.1
MIN_LR = 0.00001
MODEL_PATH_PREFIX = 'model-cnn-epoch'
MODEL_PATH_EXT = 'pth'
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
```

#### Create the train and test loader


```python
train_set = FER2013Dataset(x_train, y_train)
test_set = FER2013Dataset(x_valid, y_valid)

train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, num_workers=0, shuffle=True)
test_loader = DataLoader(test_set, batch_size=BATCH_SIZE, num_workers=0, shuffle=False)
```

#### Train the network


```python
def train(model, dataset_loader, epoch, device, optimizer, criterion):
    model.train()
    running_loss = 0.0
    for i , data in enumerate(dataset_loader, 0):
        inputs, labels = data['inputs'], data['labels']
        inputs = inputs.float()
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        
        loss.backward()
        
        optimizer.step()
        
        running_loss += loss.item()
        
        print('Train: [Epoch: {}/{}, Batch: {} ({:.0f}%), running_loss: {:.3f}]'
              .format(
                  epoch,
                  NUM_EPOCHS,
                  i + 1, 
                  i*100/len(train_loader),
                  running_loss
              ), end='\r')
    print()
    return running_loss

def test(model, dataset_loader, device, criterion):
    model.eval()
    correct = 0
    total = 0
    valid_loss = 0
    
    with torch.no_grad():
        for data in dataset_loader:
            
            images, labels = data['inputs'], data['labels']
            images = images.float()
            images, labels = images.to(device), labels.to(device)
            
            outputs = model(images)
            valid_loss += criterion(outputs, labels).item()
            
            pred = outputs.max(1, keepdim=True)[1]
            correct += pred.eq(labels.view_as(pred)).sum().item()
    
    accuracy = 100 * correct / len(test_loader.dataset)
    print('Validation: [running loss: {:.3f}, accuracy: {:.3f}]'.format(
            valid_loss, accuracy
        )
    )
    print()
    return valid_loss, accuracy

def load_model(best_model, learning_rate, device):
    checkpoint = torch.load(
        '{}-{}.{}'.format(
            MODEL_PATH_PREFIX,str(epoch), MODEL_PATH_EXT
        )
    )
    
    model = CNN()
    model.load_state_dict(checkpoint['model'])
    model.to(device)
    
    optimizer = optim.Adadelta(model.parameters(), lr=learning_rate, rho=0.95, eps=1e-08)
    optimizer.load_state_dict(checkpoint['optimizer'])
    
    for state in optimizer.state.values():
        for k, v in state.items():
            if torch.is_tensor(v):
                state[k] = v.to(device)
    return model, optimizer

def restart_training(best_model, learning_rate, device):
    model, optimizer = load_model(best_model, learning_rate, device)
    return model, optimizer
```

#### Initialize the network and loss


```python
cnn = CNN()
cnn = cnn.to(device)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adadelta(cnn.parameters(), lr=LR, rho=0.95, eps=1e-08)
```


```python
loss_es = []
best_accuracy = 0.0
last_acc = 0
best_model = -1
```


```python
count_acc = 0
epoch = 1
while epoch <= NUM_EPOCHS:
    running_loss = train(cnn, train_loader, epoch, device, optimizer, criterion)
    valid_loss, accuracy = test(cnn, test_loader, device, criterion)
    
    # record all the models that we have had so far.
    loss_es.append((running_loss, valid_loss, accuracy))
    # write model to disk.
    
    state = {
        'model': cnn.state_dict(),
        'optimizer': optimizer.state_dict()
    }
    torch.save(state, 'model-cnn-epoch-{}.pth'.format(epoch))
    
    # reset if:
    #   1. the accuracy is less than the best accuracy so far
    #   2. the accuracy is equal to the best accuracy so far.
    
    if accuracy < best_accuracy or int(accuracy) == int(best_accuracy):
        count_acc += 1
       
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_model = epoch
        print('Best Accuracy: {}'.format(best_accuracy))
    
    if count_acc == 5:
        if LR/2 < MIN_LR:
            # END TRAINING.
            break
        else:
            LR/=2
        print(
            'Plateau identified: Restarting with the best model: {} and resuced learning rate: {}.'
            .format(best_model, LR)
        )
        cnn, optimizer = restart_training(best_model, LR, device)
        # transfer everything back to the cuda cores.
        
        count_acc = 0
        epoch = best_model
    epoch+=1
    
print('Trainig complete')
```

    Train: [Epoch: 1/100, Batch: 225 (100%), running_loss: 411.739]
    Validation: [running loss: 227.689, accuracy: 25.491]
    
    Best Accuracy: 25.49080710501714
    Train: [Epoch: 2/100, Batch: 225 (100%), running_loss: 393.038]
    Validation: [running loss: 218.722, accuracy: 28.707]
    
    Best Accuracy: 28.70676223122468
    Train: [Epoch: 3/100, Batch: 225 (100%), running_loss: 380.295]
    Validation: [running loss: 211.289, accuracy: 33.456]
    
    Best Accuracy: 33.455905266438144
    Train: [Epoch: 4/100, Batch: 225 (100%), running_loss: 368.842]
    Validation: [running loss: 205.802, accuracy: 37.077]
    
    Best Accuracy: 37.07697101900904
    Train: [Epoch: 5/100, Batch: 225 (100%), running_loss: 360.366]
    Validation: [running loss: 200.844, accuracy: 38.623]
    
    Best Accuracy: 38.6226238703646
    Train: [Epoch: 6/100, Batch: 225 (100%), running_loss: 353.132]
    Validation: [running loss: 198.184, accuracy: 39.321]
    
    Best Accuracy: 39.32066064194453
    Train: [Epoch: 7/100, Batch: 225 (100%), running_loss: 346.351]
    Validation: [running loss: 195.268, accuracy: 41.072]
    
    Best Accuracy: 41.07198504206918
    Train: [Epoch: 8/100, Batch: 225 (100%), running_loss: 340.058]
    Validation: [running loss: 194.319, accuracy: 40.374]
    
    Train: [Epoch: 9/100, Batch: 225 (100%), running_loss: 333.477]
    Validation: [running loss: 192.489, accuracy: 41.078]
    
    Best Accuracy: 41.078217513244
    Train: [Epoch: 10/100, Batch: 225 (100%), running_loss: 327.268]
    Validation: [running loss: 188.461, accuracy: 42.705]
    
    Best Accuracy: 42.704892489872236
    Train: [Epoch: 11/100, Batch: 225 (100%), running_loss: 321.385]
    Validation: [running loss: 184.089, accuracy: 44.157]
    
    Best Accuracy: 44.157058273605486
    Train: [Epoch: 12/100, Batch: 225 (100%), running_loss: 315.853]
    Validation: [running loss: 182.621, accuracy: 44.556]
    
    Best Accuracy: 44.55593642879402
    Train: [Epoch: 13/100, Batch: 225 (100%), running_loss: 310.634]
    Validation: [running loss: 180.474, accuracy: 45.503]
    
    Best Accuracy: 45.50327204736678
    Train: [Epoch: 14/100, Batch: 225 (100%), running_loss: 305.258]
    Validation: [running loss: 178.474, accuracy: 46.108]
    
    Best Accuracy: 46.1078217513244
    Train: [Epoch: 15/100, Batch: 225 (100%), running_loss: 300.254]
    Validation: [running loss: 185.222, accuracy: 44.874]
    
    Train: [Epoch: 16/100, Batch: 225 (100%), running_loss: 295.854]
    Validation: [running loss: 173.481, accuracy: 47.572]
    
    Best Accuracy: 47.57245247740729
    Train: [Epoch: 17/100, Batch: 225 (100%), running_loss: 290.290]
    Validation: [running loss: 175.235, accuracy: 46.469]
    
    Plateau identified: Restarting with the best model: 16 and resuced learning rate: 0.05.
    Train: [Epoch: 17/100, Batch: 225 (100%), running_loss: 285.883]
    Validation: [running loss: 175.648, accuracy: 47.018]
    
    Train: [Epoch: 18/100, Batch: 225 (100%), running_loss: 281.138]
    Validation: [running loss: 172.586, accuracy: 46.887]
    
    Train: [Epoch: 19/100, Batch: 225 (100%), running_loss: 276.842]
    Validation: [running loss: 170.560, accuracy: 48.576]
    
    Best Accuracy: 48.575880336553446
    Train: [Epoch: 20/100, Batch: 225 (100%), running_loss: 272.216]
    Validation: [running loss: 172.676, accuracy: 49.293]
    
    Best Accuracy: 49.29261452165784
    Train: [Epoch: 21/100, Batch: 225 (100%), running_loss: 266.754]
    Validation: [running loss: 170.366, accuracy: 49.000]
    
    Train: [Epoch: 22/100, Batch: 225 (100%), running_loss: 261.706]
    Validation: [running loss: 170.911, accuracy: 49.361]
    
    Best Accuracy: 49.36117170458087
    Train: [Epoch: 23/100, Batch: 225 (100%), running_loss: 256.327]
    Validation: [running loss: 168.704, accuracy: 49.822]
    
    Best Accuracy: 49.82237457151761
    Plateau identified: Restarting with the best model: 23 and resuced learning rate: 0.025.
    Train: [Epoch: 24/100, Batch: 225 (100%), running_loss: 251.475]
    Validation: [running loss: 168.472, accuracy: 50.396]
    
    Best Accuracy: 50.39576191960112
    Train: [Epoch: 25/100, Batch: 225 (100%), running_loss: 245.756]
    Validation: [running loss: 166.176, accuracy: 50.358]
    
    Train: [Epoch: 26/100, Batch: 225 (100%), running_loss: 240.389]
    Validation: [running loss: 168.180, accuracy: 49.804]
    
    Train: [Epoch: 27/100, Batch: 225 (100%), running_loss: 234.785]
    Validation: [running loss: 164.931, accuracy: 50.882]
    
    Best Accuracy: 50.88189467123715
    Train: [Epoch: 28/100, Batch: 225 (100%), running_loss: 230.333]
    Validation: [running loss: 171.810, accuracy: 49.822]
    
    Train: [Epoch: 29/100, Batch: 225 (100%), running_loss: 224.086]
    Validation: [running loss: 172.023, accuracy: 49.131]
    
    Plateau identified: Restarting with the best model: 27 and resuced learning rate: 0.0125.
    Train: [Epoch: 28/100, Batch: 225 (100%), running_loss: 218.569]
    Validation: [running loss: 171.336, accuracy: 50.583]
    
    Train: [Epoch: 29/100, Batch: 225 (100%), running_loss: 212.323]
    Validation: [running loss: 169.109, accuracy: 52.016]
    
    Best Accuracy: 52.01620442505453
    Train: [Epoch: 30/100, Batch: 225 (100%), running_loss: 206.531]
    Validation: [running loss: 170.253, accuracy: 50.975]
    
    Train: [Epoch: 31/100, Batch: 225 (100%), running_loss: 200.178]
    Validation: [running loss: 178.156, accuracy: 52.546]
    
    Best Accuracy: 52.54596447491431
    Train: [Epoch: 32/100, Batch: 225 (100%), running_loss: 194.678]
    Validation: [running loss: 169.740, accuracy: 51.835]
    
    Train: [Epoch: 33/100, Batch: 225 (100%), running_loss: 188.374]
    Validation: [running loss: 173.871, accuracy: 51.150]
    
    Plateau identified: Restarting with the best model: 31 and resuced learning rate: 0.00625.
    Train: [Epoch: 32/100, Batch: 225 (100%), running_loss: 182.847]
    Validation: [running loss: 173.611, accuracy: 50.957]
    
    Train: [Epoch: 33/100, Batch: 225 (100%), running_loss: 176.078]
    Validation: [running loss: 175.442, accuracy: 52.334]
    
    Train: [Epoch: 34/100, Batch: 225 (100%), running_loss: 170.048]
    Validation: [running loss: 174.425, accuracy: 52.558]
    
    Best Accuracy: 52.558429417263945
    Train: [Epoch: 35/100, Batch: 225 (100%), running_loss: 164.431]
    Validation: [running loss: 186.589, accuracy: 52.608]
    
    Best Accuracy: 52.60828918666251
    Train: [Epoch: 36/100, Batch: 225 (100%), running_loss: 158.402]
    Validation: [running loss: 182.229, accuracy: 53.456]
    
    Best Accuracy: 53.455905266438144
    Train: [Epoch: 37/100, Batch: 225 (100%), running_loss: 152.742]
    Validation: [running loss: 181.543, accuracy: 52.097]
    
    Plateau identified: Restarting with the best model: 36 and resuced learning rate: 0.003125.
    Train: [Epoch: 37/100, Batch: 225 (100%), running_loss: 146.371]
    Validation: [running loss: 185.368, accuracy: 53.051]
    
    Train: [Epoch: 38/100, Batch: 225 (100%), running_loss: 141.260]
    Validation: [running loss: 195.539, accuracy: 52.777]
    
    Train: [Epoch: 39/100, Batch: 225 (100%), running_loss: 134.445]
    Validation: [running loss: 189.607, accuracy: 52.359]
    
    Train: [Epoch: 40/100, Batch: 225 (100%), running_loss: 130.926]
    Validation: [running loss: 190.465, accuracy: 53.331]
    
    Train: [Epoch: 41/100, Batch: 225 (100%), running_loss: 126.211]
    Validation: [running loss: 201.375, accuracy: 53.038]
    
    Plateau identified: Restarting with the best model: 36 and resuced learning rate: 0.0015625.
    Train: [Epoch: 37/100, Batch: 225 (100%), running_loss: 119.787]
    Validation: [running loss: 196.411, accuracy: 52.982]
    
    Train: [Epoch: 38/100, Batch: 225 (100%), running_loss: 114.515]
    Validation: [running loss: 202.529, accuracy: 53.113]
    
    Train: [Epoch: 39/100, Batch: 225 (100%), running_loss: 109.035]
    Validation: [running loss: 202.834, accuracy: 53.275]
    
    Train: [Epoch: 40/100, Batch: 225 (100%), running_loss: 104.961]
    Validation: [running loss: 216.923, accuracy: 52.484]
    
    Train: [Epoch: 41/100, Batch: 225 (100%), running_loss: 100.634]
    Validation: [running loss: 210.052, accuracy: 54.247]
    
    Best Accuracy: 54.247429105640386
    Train: [Epoch: 42/100, Batch: 225 (100%), running_loss: 96.773]
    Validation: [running loss: 214.795, accuracy: 53.880]
    
    Plateau identified: Restarting with the best model: 41 and resuced learning rate: 0.00078125.
    Train: [Epoch: 42/100, Batch: 225 (100%), running_loss: 92.697]
    Validation: [running loss: 215.752, accuracy: 54.036]
    
    Train: [Epoch: 43/100, Batch: 225 (100%), running_loss: 87.563]
    Validation: [running loss: 221.880, accuracy: 53.350]
    
    Train: [Epoch: 44/100, Batch: 225 (100%), running_loss: 83.889]
    Validation: [running loss: 223.369, accuracy: 54.646]
    
    Best Accuracy: 54.64630726082892
    Train: [Epoch: 45/100, Batch: 225 (100%), running_loss: 80.605]
    Validation: [running loss: 227.302, accuracy: 53.998]
    
    Train: [Epoch: 46/100, Batch: 225 (100%), running_loss: 78.179]
    Validation: [running loss: 224.765, accuracy: 54.515]
    
    Plateau identified: Restarting with the best model: 44 and resuced learning rate: 0.000390625.
    Train: [Epoch: 45/100, Batch: 225 (100%), running_loss: 73.140]
    Validation: [running loss: 225.311, accuracy: 54.659]
    
    Best Accuracy: 54.65877220317856
    Train: [Epoch: 46/100, Batch: 225 (100%), running_loss: 71.120]
    Validation: [running loss: 239.167, accuracy: 53.842]
    
    Train: [Epoch: 47/100, Batch: 225 (100%), running_loss: 67.789]
    Validation: [running loss: 235.639, accuracy: 53.238]
    
    Train: [Epoch: 48/100, Batch: 225 (100%), running_loss: 64.656]
    Validation: [running loss: 247.480, accuracy: 53.462]
    
    Train: [Epoch: 49/100, Batch: 225 (100%), running_loss: 60.551]
    Validation: [running loss: 241.665, accuracy: 54.260]
    
    Plateau identified: Restarting with the best model: 45 and resuced learning rate: 0.0001953125.
    Train: [Epoch: 46/100, Batch: 225 (100%), running_loss: 58.118]
    Validation: [running loss: 262.263, accuracy: 54.023]
    
    Train: [Epoch: 47/100, Batch: 225 (100%), running_loss: 55.998]
    Validation: [running loss: 263.658, accuracy: 54.509]
    
    Train: [Epoch: 48/100, Batch: 225 (100%), running_loss: 53.755]
    Validation: [running loss: 268.236, accuracy: 53.861]
    
    Train: [Epoch: 49/100, Batch: 225 (100%), running_loss: 51.144]
    Validation: [running loss: 267.671, accuracy: 54.378]
    
    Train: [Epoch: 50/100, Batch: 225 (100%), running_loss: 49.689]
    Validation: [running loss: 268.265, accuracy: 54.547]
    
    Plateau identified: Restarting with the best model: 45 and resuced learning rate: 9.765625e-05.
    Train: [Epoch: 46/100, Batch: 225 (100%), running_loss: 48.129]
    Validation: [running loss: 266.947, accuracy: 54.272]
    
    Train: [Epoch: 47/100, Batch: 225 (100%), running_loss: 45.931]
    Validation: [running loss: 283.576, accuracy: 54.752]
    
    Best Accuracy: 54.75225927080087
    Train: [Epoch: 48/100, Batch: 225 (100%), running_loss: 42.980]
    Validation: [running loss: 284.421, accuracy: 55.170]
    
    Best Accuracy: 55.16983483951387
    Train: [Epoch: 49/100, Batch: 225 (100%), running_loss: 43.252]
    Validation: [running loss: 289.787, accuracy: 55.095]
    
    Train: [Epoch: 50/100, Batch: 225 (100%), running_loss: 40.260]
    Validation: [running loss: 285.042, accuracy: 54.385]
    
    Train: [Epoch: 51/100, Batch: 225 (100%), running_loss: 38.195]
    Validation: [running loss: 293.854, accuracy: 54.914]
    
    Plateau identified: Restarting with the best model: 48 and resuced learning rate: 4.8828125e-05.
    Train: [Epoch: 49/100, Batch: 225 (100%), running_loss: 36.127]
    Validation: [running loss: 297.437, accuracy: 54.328]
    
    Train: [Epoch: 50/100, Batch: 225 (100%), running_loss: 35.646]
    Validation: [running loss: 304.020, accuracy: 55.357]
    
    Best Accuracy: 55.35680897475849
    Train: [Epoch: 51/100, Batch: 225 (100%), running_loss: 34.772]
    Validation: [running loss: 308.690, accuracy: 54.777]
    
    Train: [Epoch: 52/100, Batch: 225 (100%), running_loss: 33.454]
    Validation: [running loss: 305.000, accuracy: 54.353]
    
    Train: [Epoch: 53/100, Batch: 225 (100%), running_loss: 32.477]
    Validation: [running loss: 324.542, accuracy: 54.603]
    
    Plateau identified: Restarting with the best model: 50 and resuced learning rate: 2.44140625e-05.
    Train: [Epoch: 51/100, Batch: 225 (100%), running_loss: 30.052]
    Validation: [running loss: 310.666, accuracy: 54.833]
    
    Train: [Epoch: 52/100, Batch: 225 (100%), running_loss: 29.980]
    Validation: [running loss: 317.878, accuracy: 54.914]
    
    Train: [Epoch: 53/100, Batch: 225 (100%), running_loss: 28.661]
    Validation: [running loss: 318.212, accuracy: 54.378]
    
    Train: [Epoch: 54/100, Batch: 225 (100%), running_loss: 27.933]
    Validation: [running loss: 324.391, accuracy: 54.484]
    
    Train: [Epoch: 55/100, Batch: 225 (100%), running_loss: 27.678]
    Validation: [running loss: 323.540, accuracy: 54.758]
    
    Plateau identified: Restarting with the best model: 50 and resuced learning rate: 1.220703125e-05.
    Train: [Epoch: 51/100, Batch: 225 (100%), running_loss: 26.054]
    Validation: [running loss: 331.263, accuracy: 55.213]
    
    Train: [Epoch: 52/100, Batch: 225 (100%), running_loss: 25.162]
    Validation: [running loss: 358.932, accuracy: 54.858]
    
    Train: [Epoch: 53/100, Batch: 225 (100%), running_loss: 24.558]
    Validation: [running loss: 338.367, accuracy: 54.877]
    
    Train: [Epoch: 54/100, Batch: 225 (100%), running_loss: 23.324]
    Validation: [running loss: 329.497, accuracy: 55.145]
    
    Train: [Epoch: 55/100, Batch: 225 (100%), running_loss: 23.162]
    Validation: [running loss: 347.216, accuracy: 55.176]
    
    Trainig complete
    
